class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv0 : __torch__.torch.nn.modules.conv.Conv2d
  norm0 : __torch__.torch.nn.modules.batchnorm.BatchNorm2d
  relu0 : __torch__.torch.nn.modules.activation.ReLU
  pool0 : __torch__.torch.nn.modules.pooling.MaxPool2d
  denseblock1 : __torch__.monai.networks.nets.densenet._DenseBlock
  transition1 : __torch__.monai.networks.nets.densenet._Transition
  denseblock2 : __torch__.monai.networks.nets.densenet.___torch_mangle_54._DenseBlock
  transition2 : __torch__.monai.networks.nets.densenet.___torch_mangle_57._Transition
  denseblock3 : __torch__.monai.networks.nets.densenet.___torch_mangle_121._DenseBlock
  transition3 : __torch__.monai.networks.nets.densenet.___torch_mangle_124._Transition
  denseblock4 : __torch__.monai.networks.nets.densenet.___torch_mangle_125._DenseBlock
  norm5 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_122.BatchNorm2d
  def forward(self: __torch__.torch.nn.modules.container.___torch_mangle_126.Sequential,
    input: Tensor) -> Tensor:
    _0 = self.conv0
    _1 = self.norm0
    _2 = self.relu0
    _3 = self.pool0
    _4 = self.denseblock1
    _5 = self.transition1
    _6 = self.denseblock2
    _7 = self.transition2
    _8 = self.denseblock3
    _9 = self.transition3
    _10 = self.denseblock4
    _11 = self.norm5
    input0 = (_0).forward(input, )
    input1 = (_1).forward(input0, )
    input2 = (_2).forward(input1, )
    input3 = (_3).forward(input2, )
    input4 = (_4).forward(input3, )
    input5 = (_5).forward(input4, )
    input6 = (_6).forward(input5, )
    input7 = (_7).forward(input6, )
    input8 = (_8).forward(input7, )
    input9 = (_9).forward(input8, )
    input10 = (_10).forward(input9, )
    return (_11).forward(input10, )
  def __len__(self: __torch__.torch.nn.modules.container.___torch_mangle_126.Sequential) -> int:
    return 12
