class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  norm1 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_65.BatchNorm2d
  relu1 : __torch__.torch.nn.modules.activation.ReLU
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_66.Conv2d
  norm2 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_1.BatchNorm2d
  relu2 : __torch__.torch.nn.modules.activation.ReLU
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_2.Conv2d
  def forward(self: __torch__.torch.nn.modules.container.___torch_mangle_67.Sequential,
    input: Tensor) -> Tensor:
    _0 = self.norm1
    _1 = self.relu1
    _2 = self.conv1
    _3 = self.norm2
    _4 = self.relu2
    _5 = self.conv2
    input0 = (_0).forward(input, )
    input1 = (_1).forward(input0, )
    input2 = (_2).forward(input1, )
    input3 = (_3).forward(input2, )
    input4 = (_4).forward(input3, )
    return (_5).forward(input4, )
  def __len__(self: __torch__.torch.nn.modules.container.___torch_mangle_67.Sequential) -> int:
    return 6
