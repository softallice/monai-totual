class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  relu : __torch__.torch.nn.modules.activation.ReLU
  pool : __torch__.torch.nn.modules.pooling.AdaptiveAvgPool2d
  flatten : __torch__.torch.nn.modules.flatten.Flatten
  out : __torch__.torch.nn.modules.linear.Linear
  def forward(self: __torch__.torch.nn.modules.container.___torch_mangle_127.Sequential,
    input: Tensor) -> Tensor:
    _0 = self.relu
    _1 = self.pool
    _2 = self.flatten
    _3 = self.out
    input0 = (_0).forward(input, )
    input1 = (_1).forward(input0, )
    input2 = (_2).forward(input1, )
    return (_3).forward(input2, )
  def __len__(self: __torch__.torch.nn.modules.container.___torch_mangle_127.Sequential) -> int:
    return 4
