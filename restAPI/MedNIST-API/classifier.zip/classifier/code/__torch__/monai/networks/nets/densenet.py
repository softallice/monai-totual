class DenseNet121(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  features : __torch__.torch.nn.modules.container.___torch_mangle_126.Sequential
  class_layers : __torch__.torch.nn.modules.container.___torch_mangle_127.Sequential
  def forward(self: __torch__.monai.networks.nets.densenet.DenseNet121,
    x: Tensor) -> Tensor:
    x0 = (self.features).forward(x, )
    return (self.class_layers).forward(x0, )
class _DenseBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  denselayer1 : __torch__.monai.networks.nets.densenet._DenseLayer
  denselayer2 : __torch__.monai.networks.nets.densenet.___torch_mangle_6._DenseLayer
  denselayer3 : __torch__.monai.networks.nets.densenet.___torch_mangle_9._DenseLayer
  denselayer4 : __torch__.monai.networks.nets.densenet.___torch_mangle_13._DenseLayer
  denselayer5 : __torch__.monai.networks.nets.densenet.___torch_mangle_17._DenseLayer
  denselayer6 : __torch__.monai.networks.nets.densenet.___torch_mangle_21._DenseLayer
  def forward(self: __torch__.monai.networks.nets.densenet._DenseBlock,
    input: Tensor) -> Tensor:
    _0 = self.denselayer1
    _1 = self.denselayer2
    _2 = self.denselayer3
    _3 = self.denselayer4
    _4 = self.denselayer5
    _5 = self.denselayer6
    input0 = (_0).forward(input, )
    input1 = (_1).forward(input0, )
    input2 = (_2).forward(input1, )
    input3 = (_3).forward(input2, )
    input4 = (_4).forward(input3, )
    return (_5).forward(input4, )
  def __len__(self: __torch__.monai.networks.nets.densenet._DenseBlock) -> int:
    return 6
class _DenseLayer(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  layers : __torch__.torch.nn.modules.container.Sequential
  def forward(self: __torch__.monai.networks.nets.densenet._DenseLayer,
    x: Tensor) -> Tensor:
    new_features = (self.layers).forward(x, )
    return torch.cat([x, new_features], 1)
class _Transition(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  norm : __torch__.torch.nn.modules.batchnorm.___torch_mangle_22.BatchNorm2d
  relu : __torch__.torch.nn.modules.activation.ReLU
  conv : __torch__.torch.nn.modules.conv.___torch_mangle_23.Conv2d
  pool : __torch__.torch.nn.modules.pooling.AvgPool2d
  def forward(self: __torch__.monai.networks.nets.densenet._Transition,
    input: Tensor) -> Tensor:
    _6 = self.norm
    _7 = self.relu
    _8 = self.conv
    _9 = self.pool
    input5 = (_6).forward(input, )
    input6 = (_7).forward(input5, )
    input7 = (_8).forward(input6, )
    return (_9).forward(input7, )
  def __len__(self: __torch__.monai.networks.nets.densenet._Transition) -> int:
    return 4
