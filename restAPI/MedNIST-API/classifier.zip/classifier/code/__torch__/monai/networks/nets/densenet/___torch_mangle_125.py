class _DenseBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  denselayer1 : __torch__.monai.networks.nets.densenet.___torch_mangle_60._DenseLayer
  denselayer2 : __torch__.monai.networks.nets.densenet.___torch_mangle_64._DenseLayer
  denselayer3 : __torch__.monai.networks.nets.densenet.___torch_mangle_68._DenseLayer
  denselayer4 : __torch__.monai.networks.nets.densenet.___torch_mangle_72._DenseLayer
  denselayer5 : __torch__.monai.networks.nets.densenet.___torch_mangle_76._DenseLayer
  denselayer6 : __torch__.monai.networks.nets.densenet.___torch_mangle_80._DenseLayer
  denselayer7 : __torch__.monai.networks.nets.densenet.___torch_mangle_84._DenseLayer
  denselayer8 : __torch__.monai.networks.nets.densenet.___torch_mangle_88._DenseLayer
  denselayer9 : __torch__.monai.networks.nets.densenet.___torch_mangle_92._DenseLayer
  denselayer10 : __torch__.monai.networks.nets.densenet.___torch_mangle_96._DenseLayer
  denselayer11 : __torch__.monai.networks.nets.densenet.___torch_mangle_100._DenseLayer
  denselayer12 : __torch__.monai.networks.nets.densenet.___torch_mangle_104._DenseLayer
  denselayer13 : __torch__.monai.networks.nets.densenet.___torch_mangle_108._DenseLayer
  denselayer14 : __torch__.monai.networks.nets.densenet.___torch_mangle_112._DenseLayer
  denselayer15 : __torch__.monai.networks.nets.densenet.___torch_mangle_116._DenseLayer
  denselayer16 : __torch__.monai.networks.nets.densenet.___torch_mangle_120._DenseLayer
  def forward(self: __torch__.monai.networks.nets.densenet.___torch_mangle_125._DenseBlock,
    input: Tensor) -> Tensor:
    _0 = self.denselayer1
    _1 = self.denselayer2
    _2 = self.denselayer3
    _3 = self.denselayer4
    _4 = self.denselayer5
    _5 = self.denselayer6
    _6 = self.denselayer7
    _7 = self.denselayer8
    _8 = self.denselayer9
    _9 = self.denselayer10
    _10 = self.denselayer11
    _11 = self.denselayer12
    _12 = self.denselayer13
    _13 = self.denselayer14
    _14 = self.denselayer15
    _15 = self.denselayer16
    input0 = (_0).forward(input, )
    input1 = (_1).forward(input0, )
    input2 = (_2).forward(input1, )
    input3 = (_3).forward(input2, )
    input4 = (_4).forward(input3, )
    input5 = (_5).forward(input4, )
    input6 = (_6).forward(input5, )
    input7 = (_7).forward(input6, )
    input8 = (_8).forward(input7, )
    input9 = (_9).forward(input8, )
    input10 = (_10).forward(input9, )
    input11 = (_11).forward(input10, )
    input12 = (_12).forward(input11, )
    input13 = (_13).forward(input12, )
    input14 = (_14).forward(input13, )
    return (_15).forward(input14, )
  def __len__(self: __torch__.monai.networks.nets.densenet.___torch_mangle_125._DenseBlock) -> int:
    return 16
